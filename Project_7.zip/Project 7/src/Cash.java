

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.http.HttpSession;
/**
 * Servlet implementation class Cash
 */
@WebServlet(
		description = "CashConvert",
		urlPatterns = { "/Cash" },
		initParams = {
				@WebInitParam(name = "SELECT", value = "SELECT"),
				@WebInitParam(name = "CONVERT", value = "CONVERT"),
				@WebInitParam(name = "AMOUNT", value = "AMOUNT"),
				@WebInitParam(name = "RATE", value = "RATE"),
		})
public class Cash extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Cash() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("<h1 style = " + "text-align:center" + ">Result</h1>");
		String total, convert, select;
		double amount, rate;
		
		select = request.getParameter("SELECT");
		convert = request.getParameter("CONVERT");
		amount = Double.parseDouble(request.getParameter("AMOUNT"));
		rate = Double.parseDouble(request.getParameter("RATE"));
		total = amount + " US Dollars is " + (rate*amount) + convert;
		//response.getWriter().append("<h3 style = " + "text-align:center " + ">" + total + "</h3>");
		response.getWriter().append(total);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
